const exercise1 = require('./exercise1');

describe('FizzBuzz', () => {
    it('Not a number', () => {
        expect(() => {exercise1.fizzBuzz('Abc');}).toThrow();
        expect(() => {exercise1.fizzBuzz(null);}).toThrow();
        expect(() => {exercise1.fizzBuzz(undefined);}).toThrow();
        expect(() => {exercise1.fizzBuzz({});}).toThrow();
        expect(() => {exercise1.fizzBuzz(false);}).toThrow();
    });
    it('Number % 3', () => {
        let result = exercise1.fizzBuzz(9);
        expect(result).toBe('Fizz');
    });
    it('Number % 5', () => {
        let result = exercise1.fizzBuzz(10);
        expect(result).toBe('Buzz');
    });
    it('Number % 3 & 5', () => {
        let result = exercise1.fizzBuzz(15);
        expect(result).toBe('FizzBuzz');
    });
    it('Number not % 3 or 5', () => {
        let result = exercise1.fizzBuzz(7);
        expect(result).toBe(7);
    });
});