const lib = require('../lib');

describe('absolute', () => {
    //These are individual test cases and can be combined into a group using describe
    test('Postive input number should give positive output number', () => {
        let result = lib.absolute(1);
        expect(result).toBe(1);
    })
    
    //We can also use it: instead of test:
    it('Negative input number should give positive output number', () => {
        let result = lib.absolute(-1);
        expect(result).toBe(1);
    })
    
    test('Zero should give zero', () => {
        let result = lib.absolute(0);
        expect(result).toBe(0);
    })
})

describe('greet', () => {
    //This is too specific we can generalize using regular expressions
    it('message should show', () => {
        let result = lib.greet('Avinash');
        expect(result).toBe('Welcome Avinash');
    })

    //This is generic
    it('message should show', () => {
        let result = lib.greet('Avinash');
        expect(result).toMatch(/Avinash/); //OR
        expect(result).toContain("Avinash");

        expect().toC
    });
})

describe('greet', () => {
    //This is too specific we can generalize using regular expressions
    it('message should show', () => {
        let result = lib.greet('Avinash');
        expect(result).toBe('Welcome Avinash');
    })

    //This is generic
    //This is too specific we can generalize using regular expressions
    it('message should show', () => {
        let result = lib.greet('Avinash');
        expect(result).toMatch(/Avinash/);
        expect(result).toContain('Avinash');
    })
});

describe('getCurrencies', () => {
    it('Check arry for matching currencies', () => {
        let result = lib.getCurrencies();

        //Too general
        // expect(result).toBeDefined();
        // expect(result).not.toBeNull();

        //Too specific
        // expect(result[0]).toBe('USD');
        // expect(result[1]).toBe('AUD');
        // expect(result[2]).toBe('EUR');

        //Proper way
        // expect(result).toContain("EUR");
        // expect(result).toContain("USD");
        // expect(result).toContain("AUD");

        //Ideal way
        expect(result).toEqual(expect.arrayContaining(["EUR", "USD", "AUD"]));
    });
});

describe('getProduct', () => {
    it('Check for product Object', () => {
        let result = lib.getProduct(1);
        expect(result).toMatchObject({price: 10, id: 1});
        //.toBe method is used for equality, 
        //and these two objects are equalled with adress which are different
    });
});